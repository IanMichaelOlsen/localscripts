// script.js

document.addEventListener('DOMContentLoaded', () => {
    const authForm = document.getElementById('authForm');
    const authOutput = document.getElementById('authOutput');
    const authSection = document.getElementById('authSection');
    const tokenSection = document.getElementById('tokenSection');
    const accessTokenDisplay = document.getElementById('accessTokenDisplay');
    const copyTokenButton = document.getElementById('copyTokenButton');
    const logoutButton = document.getElementById('logoutButton');

    // Scratchpad Elements
    const scratchpadContent = document.getElementById('scratchpadContent');

    // Encryption Key (Generated on Page Load)
    const encryptionKey = CryptoJS.lib.WordArray.random(32).toString();

    // Tab elements
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');

    // Backend URL
    const BACKEND_URL = 'http://localhost:5000/api'; // Update if different

    // Handle Tab Switching
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const tabName = button.getAttribute('data-tab');
            switchTab(tabName);
        });
    });

    function switchTab(tabName) {
        // Activate the selected tab button
        tabButtons.forEach(button => {
            if (button.getAttribute('data-tab') === tabName) {
                button.classList.add('active');
            } else {
                button.classList.remove('active');
            }
        });

        // Show the corresponding tab content
        tabContents.forEach(content => {
            if (content.id === tabName) {
                content.classList.remove('hidden');
            } else {
                content.classList.add('hidden');
            }
        });

        // Adjust container margins dynamically
        adjustContainerMargins();
    }

    function adjustContainerMargins() {
        // Implementation can be added if needed
    }

    // Handle Authentication Form Submission
    authForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        clearOutput(authOutput);

        const username = document.getElementById('authUsername').value.trim();
        const password = document.getElementById('authPassword').value.trim();

        if (!username || !password) {
            displayError(authOutput, 'Both Username and Password are required.');
            return;
        }

        displayMessage(authOutput, 'Authenticating...', false);

        try {
            const response = await fetch(`${BACKEND_URL}/authenticate`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });

            if (!response.ok) {
                const errorData = await response.json();
                displayError(authOutput, `Authentication failed: ${JSON.stringify(errorData.error)}`);
                return;
            }

            const data = await response.json();
            if (data.accessToken) {
                accessTokenDisplay.value = data.accessToken;
                tokenSection.classList.remove('hidden');
                displayMessage(authOutput, 'Successfully authenticated. Access token retrieved.', false);
                // Show Tab Navigation and Logout Button
                document.querySelector('.tab-container').classList.remove('hidden');
                logoutButton.classList.remove('hidden');
                // Hide the authForm
                authForm.classList.add('hidden');
            } else {
                displayError(authOutput, 'Failed to retrieve access token.');
            }
        } catch (error) {
            displayError(authOutput, 'An unexpected error occurred: ' + error.message);
        }
    });

    // Handle Copy Token Button
    copyTokenButton.addEventListener('click', () => {
        accessTokenDisplay.select();
        accessTokenDisplay.setSelectionRange(0, 99999); // For mobile devices
        document.execCommand('copy');
        alert('Access token copied to clipboard.');
    });

    // Handle Logout
    logoutButton.addEventListener('click', () => {
        // Clear the access token display
        accessTokenDisplay.value = '';
        // Reset sections visibility
        tokenSection.classList.add('hidden');
        authForm.classList.remove('hidden');
        // Hide tabs and contents
        document.querySelector('.tab-container').classList.add('hidden');
        tabContents.forEach(content => content.classList.add('hidden'));
        // Hide Logout Button
        logoutButton.classList.add('hidden');
        // Clear outputs
        clearOutput(authOutput);
        document.querySelectorAll('.actionOutput').forEach(output => clearOutput(output));
        document.querySelectorAll('.consoleOutput').forEach(output => clearOutput(output));
    });

    /**
     * Display a message in the specified output div.
     * @param {HTMLElement} outputDiv
     * @param {string} message
     * @param {boolean} isError
     */
    function displayMessage(outputDiv, message, isError = false) {
        outputDiv.innerHTML = `<p>${message}</p>`;
        outputDiv.className = isError ? 'error' : '';
        outputDiv.style.display = 'block';
    }

    /**
     * Display an error message in the specified output div.
     * @param {HTMLElement} outputDiv
     * @param {string} error
     */
    function displayError(outputDiv, error) {
        displayMessage(outputDiv, error, true);
    }

    /**
     * Clear the content and hide the specified output div.
     * @param {HTMLElement} outputDiv
     */
    function clearOutput(outputDiv) {
        outputDiv.innerHTML = '';
        outputDiv.style.display = 'none';
    }

    // Action Forms Handling
    const actionForms = document.querySelectorAll('.actionForm');
    actionForms.forEach(form => {
        form.addEventListener('submit', async (event) => {
            event.preventDefault();
            const formId = form.id;
            if (formId === 'rulesForm') {
                await handleGetRules();
            } else if (formId === 'whitelistForm') {
                await handleWhitelistPorts();
            } else if (formId === 'manualWhitelistForm') {
                await handleManualWhitelist();
            } else if (formId === 'deleteForm') {
                await handleDeleteRules();
            } else if (formId === 'attackHistoryForm') {
                await handleGetAttackHistory();
            } else if (formId === 'announcementHistoryForm') {
                await handleGetAnnouncementHistory();
            }
        });
    });

    // Handle Get Firewall Rules
    async function handleGetRules() {
        const rulesOutput = document.getElementById('rulesOutput');
        clearOutput(rulesOutput);

        const destinationIp = document.getElementById('destinationIp').value.trim();
        const accessToken = document.getElementById('accessTokenInput').value.trim();

        if (!destinationIp) {
            displayError(rulesOutput, 'Destination IP is required.');
            return;
        }

        if (!accessToken) {
            displayError(rulesOutput, 'Access token is required.');
            return;
        }

        displayMessage(rulesOutput, 'Fetching firewall rules...', false);

        try {
            const response = await fetch(`${BACKEND_URL}/rules?destinationIp=${encodeURIComponent(destinationIp)}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${accessToken}`
                }
            });

            if (!response.ok) {
                const errorData = await response.json();
                displayError(rulesOutput, `Failed to retrieve rules: ${JSON.stringify(errorData.error)}`);
                return;
            }

            const data = await response.json();
            const rules = data.rules || [];

            if (rules.length > 0) {
                displayRules(destinationIp, rules, rulesOutput);
            } else {
                displayMessage(rulesOutput, `No rules found for IP ${destinationIp}.`, false);
            }
        } catch (error) {
            displayError(rulesOutput, 'An unexpected error occurred: ' + error.message);
        }
    }

    // Handle Whitelist Ports
    async function handleWhitelistPorts() {
        const whitelistOutput = document.getElementById('whitelistOutput');
        const whitelistConsole = document.getElementById('whitelistConsole');
        clearOutput(whitelistOutput);
        clearOutput(whitelistConsole);

        const destinationIp = document.getElementById('destinationIpWhitelist').value.trim();
        const accessToken = document.getElementById('accessTokenInputWhitelist').value.trim();
        const portsInput = document.getElementById('portsToWhitelist').value.trim();
        const protocol = document.querySelector('input[name="protocol"]:checked').value;

        if (!destinationIp || !portsInput) {
            displayError(whitelistOutput, 'Destination IP and Ports are required.');
            return;
        }

        if (!accessToken) {
            displayError(whitelistOutput, 'Access token is required.');
            return;
        }

        displayMessage(whitelistOutput, 'Whitelisting ports...', false);
        whitelistConsole.style.display = 'block';

        const errors = [];

        try {
            // Parse ports input
            const ports = parsePortsInput(portsInput);

            // Block all ports first
            await fetch(`${BACKEND_URL}/blockAllPorts`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ destinationIp })
            });

            // Whitelist specified ports individually
            for (const portItem of ports) {
                if (typeof portItem === 'number') {
                    // Individual port
                    try {
                        await whitelistPort(accessToken, destinationIp, portItem, protocol);
                        appendConsoleMessage(whitelistConsole, `Port ${portItem} whitelisted successfully.`, 'success');
                    } catch (error) {
                        const errorMsg = `Error whitelisting port ${portItem}: ${error.message || error}`;
                        appendConsoleMessage(whitelistConsole, errorMsg, 'error');
                        errors.push(errorMsg);
                    }
                } else {
                    // Port range
                    for (let p = portItem.start; p <= portItem.end; p++) {
                        try {
                            await whitelistPort(accessToken, destinationIp, p, protocol);
                            appendConsoleMessage(whitelistConsole, `Port ${p} whitelisted successfully.`, 'success');
                        } catch (error) {
                            const errorMsg = `Error whitelisting port ${p}: ${error.message || error}`;
                            appendConsoleMessage(whitelistConsole, errorMsg, 'error');
                            errors.push(errorMsg);
                        }
                    }
                }
            }

            if (errors.length > 0) {
                displayError(whitelistOutput, 'Some ports failed to whitelist. See console for details.');
            } else {
                displayMessage(whitelistOutput, 'All ports whitelisted successfully.', false);
            }
        } catch (error) {
            displayError(whitelistOutput, 'An unexpected error occurred: ' + error.message);
        }
    }

    async function whitelistPort(accessToken, destinationIp, port, protocol) {
        const response = await fetch(`${BACKEND_URL}/whitelistPort`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ destinationIp, port, protocol })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(JSON.stringify(errorData.error));
        }
    }

    // Handle Manual Whitelist Entry
    async function handleManualWhitelist() {
        const manualWhitelistOutput = document.getElementById('manualWhitelistOutput');
        const manualWhitelistConsole = document.getElementById('manualWhitelistConsole');
        clearOutput(manualWhitelistOutput);
        clearOutput(manualWhitelistConsole);

        const accessToken = document.getElementById('accessTokenInputManual').value.trim();
        const source = document.getElementById('sourceManual').value.trim() || '0.0.0.0/0';
        const destination = document.getElementById('destinationManual').value.trim();
        const protocol = document.getElementById('protocolManual').value.trim();
        const dst_port = document.getElementById('dstPortManual').value.trim();
        const whitelist = document.getElementById('whitelistManual').value === 'true';
        const priority = document.getElementById('priorityManual').value === 'true';
        const comment = document.getElementById('commentManual').value.trim();

        if (!accessToken || !destination) {
            displayError(manualWhitelistOutput, 'Access token and Destination are required.');
            return;
        }

        displayMessage(manualWhitelistOutput, 'Adding manual whitelist rule...', false);
        manualWhitelistConsole.style.display = 'block';

        try {
            const ruleData = {
                source,
                destination,
                protocol,
                dst_port,
                whitelist,
                priority,
                comment
            };

            const response = await fetch(`${BACKEND_URL}/createRule`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(ruleData)
            });

            if (!response.ok) {
                const errorData = await response.json();
                appendConsoleMessage(manualWhitelistConsole, `Error adding rule: ${JSON.stringify(errorData.error)}`, 'error');
                displayError(manualWhitelistOutput, 'Failed to add manual whitelist rule.');
                return;
            }

            appendConsoleMessage(manualWhitelistConsole, 'Manual whitelist rule added successfully.', 'success');
            displayMessage(manualWhitelistOutput, 'Manual whitelist rule added successfully.', false);
        } catch (error) {
            displayError(manualWhitelistOutput, 'An unexpected error occurred: ' + error.message);
        }
    }

    // Handle Delete Firewall Rules
    async function handleDeleteRules() {
        const deleteOutput = document.getElementById('deleteOutput');
        const deleteConsole = document.getElementById('deleteConsole');
        clearOutput(deleteOutput);
        clearOutput(deleteConsole);

        const destinationIp = document.getElementById('destinationIpDelete').value.trim();
        const accessToken = document.getElementById('accessTokenInputDelete').value.trim();
        const ruleIdsInput = document.getElementById('ruleIdsDelete').value.trim();

        if (!destinationIp) {
            displayError(deleteOutput, 'Destination IP is required.');
            return;
        }

        if (!accessToken) {
            displayError(deleteOutput, 'Access token is required.');
            return;
        }

        displayMessage(deleteOutput, 'Deleting firewall rules...', false);
        deleteConsole.style.display = 'block';

        const errors = [];

        try {
            let ruleIds = [];

            if (ruleIdsInput) {
                // User provided specific rule IDs
                ruleIds = ruleIdsInput.split(',').map(id => id.trim());
            } else {
                // Fetch all rules for the IP
                const response = await fetch(`${BACKEND_URL}/rules?destinationIp=${encodeURIComponent(destinationIp)}`, {
                    method: 'GET',
                    headers: {
                        'Authorization': `Bearer ${accessToken}`
                    }
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    displayError(deleteOutput, `Failed to retrieve rules: ${JSON.stringify(errorData.error)}`);
                    return;
                }

                const data = await response.json();
                const rules = data.rules || [];

                if (rules.length === 0) {
                    displayMessage(deleteOutput, `No rules found for IP ${destinationIp}.`, false);
                    return;
                }

                ruleIds = rules.map(rule => rule.id);
            }

            // Delete each rule individually
            for (const ruleId of ruleIds) {
                try {
                    await deleteRule(accessToken, ruleId);
                    appendConsoleMessage(deleteConsole, `Rule ID ${ruleId} deleted successfully.`, 'success');
                } catch (error) {
                    const errorMsg = `Error deleting rule ID ${ruleId}: ${error.message || error}`;
                    appendConsoleMessage(deleteConsole, errorMsg, 'error');
                    errors.push(errorMsg);
                }
            }

            if (errors.length > 0) {
                displayError(deleteOutput, 'Some rules failed to delete. See console for details.');
            } else {
                displayMessage(deleteOutput, 'Specified firewall rules deleted successfully.', false);
            }
        } catch (error) {
            displayError(deleteOutput, 'An unexpected error occurred: ' + error.message);
        }
    }

    async function deleteRule(accessToken, ruleId) {
        const response = await fetch(`${BACKEND_URL}/rules/${ruleId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${accessToken}`
            }
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(JSON.stringify(errorData.error));
        }
    }
    // Function to handle fetching attack history
    async function handleGetAttackHistory() {
        const attackHistoryOutput = document.getElementById('attackHistoryOutput');
        clearOutput(attackHistoryOutput);

        const accessToken = document.getElementById('accessTokenInputHistory').value.trim();
        const host = document.getElementById('hostInput').value.trim();
        const prefix = document.getElementById('prefixInput').value.trim();
        const startTime = document.getElementById('startTimeInput').value;
        const endTime = document.getElementById('endTimeInput').value;

        if (!accessToken) {
            displayError(attackHistoryOutput, 'Access token is required.');
            return;
        }

        displayMessage(attackHistoryOutput, 'Fetching attack history...', false);

        try {
            const params = new URLSearchParams();

            if (host) params.append('host', host);
            if (prefix) params.append('prefix', prefix);
            if (startTime) params.append('start', startTime);
            if (endTime) params.append('end', endTime);

            const response = await fetch(`${BACKEND_URL}/attackHistory?${params.toString()}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${accessToken}`
                }
            });

            if (!response.ok) {
                const errorData = await response.json();
                displayError(attackHistoryOutput, `Failed to retrieve attack history: ${JSON.stringify(errorData.error)}`);
                return;
            }

            const data = await response.json();

            displayAttackHistory(data.attack_history, attackHistoryOutput);

        } catch (error) {
            displayError(attackHistoryOutput, 'An unexpected error occurred: ' + error.message);
        }
    }

    // Function to handle fetching announcement history
    async function handleGetAnnouncementHistory() {
        const announcementHistoryOutput = document.getElementById('announcementHistoryOutput');
        clearOutput(announcementHistoryOutput);

        const accessToken = document.getElementById('accessTokenInputAnnouncement').value.trim();
        const startTime = document.getElementById('startTimeAnnouncement').value;
        const endTime = document.getElementById('endTimeAnnouncement').value;

        if (!accessToken) {
            displayError(announcementHistoryOutput, 'Access token is required.');
            return;
        }

        displayMessage(announcementHistoryOutput, 'Fetching announcement history...', false);

        try {
            const params = new URLSearchParams();

            if (startTime) params.append('start', startTime);
            if (endTime) params.append('end', endTime);

            const response = await fetch(`${BACKEND_URL}/announcementHistory?${params.toString()}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${accessToken}`
                }
            });

            if (!response.ok) {
                const errorData = await response.json();
                displayError(announcementHistoryOutput, `Failed to retrieve announcement history: ${JSON.stringify(errorData.error)}`);
                return;
            }

            const data = await response.json();

            displayAnnouncementHistory(data.announcement_history, announcementHistoryOutput);

        } catch (error) {
            displayError(announcementHistoryOutput, 'An unexpected error occurred: ' + error.message);
        }
    }

    // Function to display attack history
    function displayAttackHistory(history, outputDiv) {
        if (!history || history.length === 0) {
            displayMessage(outputDiv, 'No attack history found.', false);
            return;
        }

        outputDiv.innerHTML = '<h3>Attack History:</h3>';

        history.forEach((attack) => {
            const attackDiv = document.createElement('div');
            attackDiv.className = 'history-entry';
            const pre = document.createElement('pre');
            pre.textContent = JSON.stringify(attack, null, 2);
            attackDiv.appendChild(pre);
            outputDiv.appendChild(attackDiv);
        });

        outputDiv.style.display = 'block';
    }

    // Function to display announcement history
    function displayAnnouncementHistory(history, outputDiv) {
        if (!history || history.length === 0) {
            displayMessage(outputDiv, 'No announcement history found.', false);
            return;
        }

        outputDiv.innerHTML = '<h3>Announcement History:</h3>';

        history.forEach((announcement) => {
            const announcementDiv = document.createElement('div');
            announcementDiv.className = 'history-entry';
            const pre = document.createElement('pre');
            pre.textContent = JSON.stringify(announcement, null, 2);
            announcementDiv.appendChild(pre);
            outputDiv.appendChild(announcementDiv);
        });

        outputDiv.style.display = 'block';
    }

    /**
     * Display rules in the output div.
     * @param {string} ip
     * @param {Array} rules
     * @param {HTMLElement} outputDiv
     */
    function displayRules(ip, rules, outputDiv) {
        outputDiv.innerHTML = `<h3>Rules for IP ${ip}:</h3>`;

        rules.forEach((rule, index) => {
            const ruleDiv = document.createElement('div');
            ruleDiv.className = 'rule';
            ruleDiv.innerHTML = `<strong>Rule ${index + 1}:</strong> <pre>${JSON.stringify(rule, null, 2)}</pre>`;
            outputDiv.appendChild(ruleDiv);
        });

        outputDiv.style.display = 'block';
    }

    /**
     * Parse the ports input string into an array of numbers and ranges.
     * @param {string} input
     * @returns {Array}
     */
    function parsePortsInput(input) {
        const ports = [];
        const parts = input.split(',');

        parts.forEach(part => {
            part = part.trim();
            if (part.includes('-')) {
                const [start, end] = part.split('-').map(Number);
                ports.push({ start, end });
            } else {
                ports.push(Number(part));
            }
        });

        return ports;
    }

    /**
     * Append a message to the console output.
     * @param {HTMLElement} consoleDiv
     * @param {string} message
     * @param {string} type - 'success' or 'error'
     */
    function appendConsoleMessage(consoleDiv, message, type = 'info') {
        const messageDiv = document.createElement('div');
        messageDiv.className = `console-message ${type}`;
        messageDiv.textContent = message;
        consoleDiv.appendChild(messageDiv);
    }

    // Handle Scratchpad Persistence with Encryption
    // Load and decrypt content from localStorage
    if (localStorage.getItem('encryptedScratchpadContent')) {
        try {
            const encryptedData = localStorage.getItem('encryptedScratchpadContent');
            const decryptedData = CryptoJS.AES.decrypt(encryptedData, encryptionKey).toString(CryptoJS.enc.Utf8);
            scratchpadContent.value = decryptedData;
        } catch (error) {
            console.error('Error decrypting scratchpad content:', error);
            scratchpadContent.value = '';
        }
    }

    // Save encrypted content to localStorage on input
    scratchpadContent.addEventListener('input', () => {
        const plainText = scratchpadContent.value;
        const encryptedData = CryptoJS.AES.encrypt(plainText, encryptionKey).toString();
        localStorage.setItem('encryptedScratchpadContent', encryptedData);
    });

    // Delete encrypted data from localStorage when the page is closed
    window.addEventListener('beforeunload', () => {
        localStorage.removeItem('encryptedScratchpadContent');
    });
});
