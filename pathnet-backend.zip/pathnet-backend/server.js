// server.js

const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Environment Variables
const AUTH_URL = 'https://api.path.net/token';
const RULES_URL = 'https://api.path.net/rules';
const ATTACK_HISTORY_URL = 'https://api.path.net/attack_history';
const ANNOUNCEMENT_HISTORY_URL = 'https://api.path.net/announcement_history';

// Route to handle authentication
app.post('/api/authenticate', async (req, res) => {
    const { username, password } = req.body;

    const payload = new URLSearchParams();
    payload.append('grant_type', 'password');
    payload.append('username', username);
    payload.append('password', password);

    try {
        const response = await axios.post(AUTH_URL, payload.toString(), {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        });

        if (response.data.access_token) {
            res.json({ accessToken: response.data.access_token });
        } else {
            res.status(400).json({ error: 'Failed to retrieve access token.' });
        }
    } catch (error) {
        handleAxiosError(res, error);
    }
});

// Route to fetch firewall rules
app.get('/api/rules', async (req, res) => {
    const { destinationIp } = req.query;
    const accessToken = extractAccessToken(req);

    if (!accessToken) {
        return res.status(401).json({ error: 'Invalid or missing access token.' });
    }

    try {
        const response = await axios.get(RULES_URL, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Accept': 'application/json'
            },
            params: {
                destination: destinationIp
            }
        });

        res.json(response.data);
    } catch (error) {
        handleAxiosError(res, error);
    }
});

// Route to block all ports
app.post('/api/blockAllPorts', async (req, res) => {
    const { destinationIp } = req.body;
    const accessToken = extractAccessToken(req);

    if (!accessToken) {
        return res.status(401).json({ error: 'Invalid or missing access token.' });
    }

    const ruleData = {
        source: "0.0.0.0/0",
        destination: destinationIp,
        dst_port: "1-65535",
        whitelist: false,
        priority: true,
        comment: "Default deny all rule"
    };

    try {
        await axios.post(RULES_URL, ruleData, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            }
        });
        res.status(200).json({ message: 'Authentication Successful' });
    } catch (error) {
        handleAxiosError(res, error);
    }
});

// Route to whitelist a single port
app.post('/api/whitelistPort', async (req, res) => {
    const { destinationIp, port, protocol } = req.body;
    const accessToken = extractAccessToken(req);

    if (!accessToken) {
        return res.status(401).json({ error: 'Invalid or missing access token.' });
    }

    try {
        await createRule(accessToken, destinationIp, port, protocol);
        res.status(200).json({ message: `Port ${port} whitelisted successfully.` });
    } catch (error) {
        handleAxiosError(res, error);
    }
});

// Route to create a manual rule
app.post('/api/createRule', async (req, res) => {
    const accessToken = extractAccessToken(req);
    const ruleData = req.body;

    if (!accessToken) {
        return res.status(401).json({ error: 'Invalid or missing access token.' });
    }

    try {
        await axios.post(RULES_URL, ruleData, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            }
        });
        res.status(200).json({ message: 'Rule created successfully.' });
    } catch (error) {
        handleAxiosError(res, error);
    }
});

// Route to get attack history
app.get('/api/attackHistory', async (req, res) => {
    const accessToken = extractAccessToken(req);

    if (!accessToken) {
        return res.status(401).json({ error: 'Invalid or missing access token.' });
    }

    const { host, prefix, start, end } = req.query;

    const params = {};

    if (host) params.host = host;
    if (prefix) params.prefix = prefix;
    if (start) params.start = start;
    if (end) params.end = end;

    try {
        const response = await axios.get(ATTACK_HISTORY_URL, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Accept': 'application/json'
            },
            params
        });

        res.json(response.data);
    } catch (error) {
        handleAxiosError(res, error);
    }
});

// Route to get announcement history
app.get('/api/announcementHistory', async (req, res) => {
    const accessToken = extractAccessToken(req);

    if (!accessToken) {
        return res.status(401).json({ error: 'Invalid or missing access token.' });
    }

    const { start, end } = req.query;

    const params = {};

    if (start) params.start = start;
    if (end) params.end = end;

    try {
        const response = await axios.get(ANNOUNCEMENT_HISTORY_URL, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Accept': 'application/json'
            },
            params
        });

        res.json(response.data);
    } catch (error) {
        handleAxiosError(res, error);
    }
});

// Helper function to create a rule
async function createRule(accessToken, destinationIp, port, protocol) {
    const ruleData = {
        source: "0.0.0.0/0",
        destination: destinationIp,
        protocol,
        dst_port: port.toString(),
        whitelist: true,
        priority: false,
        comment: `Allow port ${port}`
    };

    await axios.post(RULES_URL, ruleData, {
        headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
        }
    });
}

// Route to delete a specific rule
app.delete('/api/rules/:ruleId', async (req, res) => {
    const { ruleId } = req.params;
    const accessToken = extractAccessToken(req);

    if (!accessToken) {
        return res.status(401).json({ error: 'Invalid or missing access token.' });
    }

    try {
        const response = await axios.delete(`${RULES_URL}/${ruleId}`, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Accept': 'application/json'
            }
        });
        res.status(response.status).json({ message: `Rule ${ruleId} deleted successfully.` });
    } catch (error) {
        handleAxiosError(res, error);
    }
});

// Helper function to extract access token from request
function extractAccessToken(req) {
    const authHeader = req.headers['authorization'];
    if (!authHeader) {
        return null;
    }
    const tokenParts = authHeader.split(' ');
    if (tokenParts.length !== 2 || tokenParts[0] !== 'Bearer') {
        return null;
    }
    return tokenParts[1];
}

// Helper function to handle Axios errors
function handleAxiosError(res, error) {
    if (error.response) {
        res.status(error.response.status).json({ error: error.response.data });
    } else {
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
